WASD - move forward, left, backward, right
Mouse - pitch, yaw camera
left click - shoot
E - reload
R(when game finish) - restart
Q near satelite - start satelite and refil ammo if satelite is ready

1,2 - toggle front face culling
3,4 - toggle wireframe mode
5,6,7 - toggle point, directional, spotlight