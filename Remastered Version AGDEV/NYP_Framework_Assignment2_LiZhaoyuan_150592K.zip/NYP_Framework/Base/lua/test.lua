
title = "DM2240 - Week 14 Scripting"
width = 1
height = 1

moveForward = "W"
moveBackward = "S"
moveLeft = "A"
moveRight = "D"
reload = "E"
reset = "P"

fireRate = 0.2f
ammo = 15
maxclip = 1
Waypoint_A_1 = { x = 10.0, y = 0.0, z = 50.0 }
