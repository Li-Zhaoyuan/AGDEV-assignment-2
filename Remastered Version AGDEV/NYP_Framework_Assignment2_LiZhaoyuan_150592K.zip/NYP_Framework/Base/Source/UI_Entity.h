#pragma once

#include "EntityBase.h"

class UI_Entity : public EntityBase
{
public:
    UI_Entity();
    virtual ~UI_Entity();
};