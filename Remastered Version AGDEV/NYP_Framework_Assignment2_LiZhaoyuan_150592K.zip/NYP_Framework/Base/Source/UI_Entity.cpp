#include "UI_Entity.h"

UI_Entity::UI_Entity()
{
    name_ = "UI Element";
}

UI_Entity::~UI_Entity()
{

}